package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int topScore=100;
        int failMark=32;

        if(topScore==100)
        {
            System.out.println("A+");
        }
       
    }
}
