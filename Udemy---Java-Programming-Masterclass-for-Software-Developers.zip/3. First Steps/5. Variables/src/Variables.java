public class Variables {
    public static void main(String[] args){

            int a;
            float b;
            double c;
            long d;
            short e;
<<<<<<< HEAD

=======
           // int,float,doule,long,short those are  variables in java or others lanaguge 
>>>>>>> 6f8554b0875e0e090d91461a096e13891377998b

    }
}
