package com.company;

public class Main {

    public static void main(String[] args) {


        int value=1;
        System.out.println((float) value/2);


    }
}
