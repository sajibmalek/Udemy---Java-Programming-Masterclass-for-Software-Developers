public class MainMethod {
    public static void main(String [] args){

    }
}
