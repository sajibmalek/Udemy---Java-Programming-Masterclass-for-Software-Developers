package com.company;

public class Main {

    public static void main(String[] args) {
	        // byte
            //short
            //int
            //float
            //long
            //double
            //char
            //boolean
        System.out.println();
        String myString="This is my String";
        System.out.println("This is my String = " + myString);
        myString=myString + "," + "and this more String";
        System.out.println("myString = " + myString);
        myString=myString +" " + "\u00A9"+" " + "2020";
        System.out.println("myString = " + myString);

        String lastString="10.10";
                int myInt=10;
          lastString=lastString+myInt;
        System.out.println("lastStringValue = " + lastString);
        



    }
}
