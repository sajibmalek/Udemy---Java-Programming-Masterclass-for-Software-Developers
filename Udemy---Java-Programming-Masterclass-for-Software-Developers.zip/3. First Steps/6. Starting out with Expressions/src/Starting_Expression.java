public class Starting_Expression {

    public static void main(String[]args){

        int myFirstNumber=10;
        int mySecondNumber=20;
        System.out.println(myFirstNumber + mySecondNumber);
        System.out.println(myFirstNumber - mySecondNumber);
        System.out.println(myFirstNumber * mySecondNumber);
        System.out.println((float) myFirstNumber / mySecondNumber);

    }
}
