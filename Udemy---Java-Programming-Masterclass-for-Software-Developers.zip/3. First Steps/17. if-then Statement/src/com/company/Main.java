package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int a=2, b=4;

        if(a>b){
            System.out.println("a is gather than b");
        }else{
            System.out.println("b is gather than a");
        }

        boolean isAlien=false;
        if (isAlien == true){
            System.out.println("It is not an Alien!");
        }
        else {
            System.out.println("It is an Alien!");
        }

    }
}
