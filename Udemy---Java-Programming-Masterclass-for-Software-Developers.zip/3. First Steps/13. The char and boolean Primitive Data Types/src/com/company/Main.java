package com.company;

public class Main {

    public static void main(String[] args) {
	 
        char mychar='D';
        mychar='\u0044';
        System.out.println("mychar = " + mychar);
        System.out.println("mychar = " + mychar);

        String unicode= "\u2764";

        System.out.println("unicode = " + unicode);
        System.out.println("unicode = " + unicode);
        System.out.println("unicode = " + unicode);
        System.out.println("unicode = " + unicode);
        System.out.println("unicode = " + unicode);




    }
}
