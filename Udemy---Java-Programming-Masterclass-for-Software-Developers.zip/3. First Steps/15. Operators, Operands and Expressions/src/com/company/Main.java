package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int a=2-1;  // = (addition) it's call assign Operator
                    // - (abstraction) it's call Operator
                    // 2,1 those are Operands
                    // logic result like 2*5=10 , 5-3=2 => 10, 2 are the Expression
        System.out.println(a);

    }
}
