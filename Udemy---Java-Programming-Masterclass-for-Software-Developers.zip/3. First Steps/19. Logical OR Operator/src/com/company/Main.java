package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int topscore=100;
        int lowScore=33;
        if (topscore<=100 || lowScore!=topscore){
            System.out.println("Result");
        }
    }
}
