package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
	 String numberasString="2021";
        System.out.println("String Number "+numberasString);
        int number= Integer.parseInt(numberasString);
        System.out.println(number);
        numberasString +=1;
        number +=1;
        System.out.println(numberasString);
        System.out.println(number);

    }
}
