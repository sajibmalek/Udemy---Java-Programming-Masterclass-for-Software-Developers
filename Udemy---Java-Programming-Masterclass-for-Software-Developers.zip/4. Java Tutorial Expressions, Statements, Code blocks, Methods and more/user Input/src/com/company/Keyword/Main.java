package com.company.Keyword;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        System.out.println("enter your date of birth");
        boolean hasNextInt=scanner.hasNextInt();
        if (hasNextInt){
            // int year= Integer.parseInt(scanner.nextLine()); ==  scanner.nextLine(); are same
        int year=  scanner.nextInt();
        scanner.nextLine();
         int age= 2021-year;
         if(year >=0 && year >=100){
               System.out.println(age);
         }else {
             System.out.println("something went worng");
         }


        }

        scanner.close();

    }
}
