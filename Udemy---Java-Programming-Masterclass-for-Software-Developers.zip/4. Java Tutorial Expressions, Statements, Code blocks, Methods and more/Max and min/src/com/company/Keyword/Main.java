package com.company.Keyword;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
 Scanner scanner=new Scanner(System.in);
        int max=0, min=0;

        while (true){
            System.out.println("Enter a Number");
            boolean isInt= scanner.hasNextInt();
            if (isInt ){
                int number=scanner.nextInt();
                if (number >max){
                    max=number;
                }
                if(number<min){
                    min=number;
                }

            }
else {
    break;
}

scanner.nextLine();

            }
        System.out.println("max number "+max +"min number "+min);
        scanner.close();
    }
}
