package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
        int counta=3;
        int count=0;
        while (count!=5){
            System.out.println("count "+count);
            count++;

        }

    do {

        System.out.println("vale is "+counta);
        counta++;
    }while (counta !=6);

     }
}
