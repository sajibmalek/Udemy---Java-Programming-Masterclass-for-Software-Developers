package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
	calculateScore("sajib",500);
int nScore=    calculateScore(78);
// nScore using variable for return value print
        System.out.println(nScore);
        calculateScore();
        calFeetandInchsToCentimeter(7,5);
    }

    public static int calculateScore(String name, int score){
        System.out.println("Player name "+name +" and his score "+score);
        return score*10;
    }
    public static int calculateScore( int score){
        // for method overloading we can change parameter numbers or data type
        System.out.println("Player name "+ score );
        return score*10;
    }
    public static int calculateScore(){
        // for method overloading we can change parameter numbers or data type
        System.out.println("Player name " );
        return 0;
    }
 public static double calFeetandInchsToCentimeter(double feet, double inches){

       if((feet <0 )|| ((inches<0) || ((inches>12)))){
           return -1;
       }

     double centimeters= (feet*12)* 2.54;
     centimeters +=inches*2.54;
     System.out.println(feet+" feets "+inches+" inches "+ centimeters +" cm");
     return centimeters;
 }




}
