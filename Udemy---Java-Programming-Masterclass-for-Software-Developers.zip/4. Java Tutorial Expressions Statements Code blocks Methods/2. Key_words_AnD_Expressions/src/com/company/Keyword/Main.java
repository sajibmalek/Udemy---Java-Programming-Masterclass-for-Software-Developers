package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
	// write your code here
        //int int=4;
        // here int is a keyword,
        System.out.println("Your text\n this is also a expression");



        int score=100;
        if(score>99){
            System.out.println("huha");
            score=0;
            System.out.println(score);
        }



    }
}
