package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
        int result=calScore(1500);
        displayhihgscore("sajib",result);
       result=calScore(900);
       displayhihgscore("malek",result);
        result=calScore(400);
        displayhihgscore("abdul ",result);
        result=calScore(50);
        displayhihgscore("abdul",result);
    }

    public  static void displayhihgscore(String playername,int palysocre){
        System.out.println(playername+"he managed the player"
                +palysocre+"on the high table");

    }

    public static int calScore(int palysocre){
        if(palysocre>1000){
            return 1;
        }
        else if(palysocre >500 && palysocre<1000){
            return 2;
        }
        else if(palysocre>100&&palysocre<500){
            return 3;
        }
        else {
            return 4;
        }
    }
}
