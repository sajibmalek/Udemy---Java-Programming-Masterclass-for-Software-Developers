package com.company.Keyword;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int myVariable=400;
        myVariable++;
        myVariable--;
        System.out.println("this is test\n");
        System.out.println("this is "+
                "another "+
                "test");

    }
}
