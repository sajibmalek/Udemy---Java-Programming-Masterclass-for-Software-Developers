package com.company.Keyword;

public class Main {

    public static void main(String[] args) {

 calmethod(true,1000,909,300);

      calmethod(true,10000,454,2323);

    }
    public  static int calmethod( boolean gameOver, int score,int lavelcamplited, int bonus){

        if(gameOver){
            int finalScore= score+(lavelcamplited*bonus);
            finalScore +=score;
            System.out.println(" Your final score "+finalScore);;
            return finalScore;
        }
        else {
            return -1;
        }

    }
}
